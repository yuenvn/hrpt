<?php
namespace app\admin\model;
use think\Model;
class Staff extends Model
{
    protected $field = true;  //忽略数据库表不存在的字段
}
